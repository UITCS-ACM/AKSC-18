<?php
defined('BASEPATH') OR exit('No direct script access is allowed');
class Login_Model extends MY_Model
{
    public function __construct()
    {
        parent::__construct();
    }

    public function check_user($user,$pass)
    {
           $sql="SELECT * FROM users WHERE user_name='$user' and user_pass=md5('$pass')";
           $result=$this->conn->query($sql);
           return $result;
    }
}
 ?>

<?php
defined('BASEPATH') OR exit('No Direct Script Access is allowed');
class Aksc_model extends MY_Model
{
    public function __construct()
    {
        parent::__construct();
    }

    public function insert_reg_record($uni_name,$team_name,$comp_name,$team_count,$m_name,$m_contact,$m_nic,$m_email)
    {
       $sql="INSERT INTO registration(id,uni_name,team_name,comp,team_count,m1_name,m1_contact,m1_nic,m1_email,m2_name,m2_contact,m2_nic,m2_email,m3_name,m3_contact,m3_nic,m3_email,m4_name,m4_contact,m4_nic,m4_email,m5_name,m5_contact,m5_nic,m5_email)
             VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
      $id=null; $time=null;
      $stmp=$this->conn->prepare($sql);
      $stmp->bind_param('issssssssssssssssssssssss',$id,$uni_name,$team_name,$comp_name,$team_count,$m_name[0],$m_contact[0],$m_nic[0],$m_email[0],$m_name[1],$m_contact[1],$m_nic[1],$m_email[1],$m_name[2],$m_contact[2],$m_nic[2]
       ,$m_email[2],$m_name[3],$m_contact[3],$m_nic[3],$m_email[3],$m_name[4],$m_contact[4],$m_nic[4],$m_email[4]);

      if($stmp===FALSE) die("Unable to insert: ".$stmp->error);
      $stmp->execute();
      $stmp->close();

      $last_id=$this->conn->insert_id;

      return $last_id;

    }


}
?>

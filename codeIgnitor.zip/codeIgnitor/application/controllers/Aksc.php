<?php

class Aksc extends MY_Controller
{
       private $title="AKSC'18";
       private $data=array();
       private $navbar_element=array(
          "navbar"=>array(
            "HOME"=>"#HOME",
            "ABOUT"=>"#ABOUT",
            "COMPETITIONS"=>"#COMPETITIONS",
            "SPONSORS"=>"#SPONSORS",
            "CONTACT"=>"#CONTACT"
          ),
          "event"=>"AKSC\'18",
          "offset"=>520,
          "image"=>"aksc-logo.png"
       );

       private $comp=array();




       public function __construct()
       {
           parent::__construct($this->title);
           $this->load->model('aksc_model');
           $this->load->library('session');

       }



       public function index()
       {
           $this->Header();
           $this->Home();
           $this->Navbar($this->navbar_element);
           $this->About();
           $this->Comp();
           $this->Sponsors();
           $this->Contact();
           $this->Footer();
       }


       /* Function for display Home */
       private function Home()
       {
            $this->load->view('web/components/aksc/aksc_home');
       }


       /* Function for display about us section */
       private function About()
       {
            $this->load->view('web/components/aksc/aksc_about');
       }


       /* Function for display Compe Section */
       private function Comp()
       {
            $table="competitions";
            $this->data['result']=$this->aksc_model->get_all($table);
            $this->load->view('web/components/aksc/aksc_competitions',$this->data);
       }


       /* Function for display Sponsors*/
       private function Sponsors()
       {
            $this->load->view('web/components/aksc/aksc_sponsors');
       }


       public function Reg_Form()            /* FUNCTION RESPONSIBLE FOR DISPLAYING REGISTRATION FORM*/
       {
          $error=FALSE;
          $m_namer_error=array();
          $m_contact_error=array();
          $m_nic_error=array();


           if(isset($_POST['register'])){
           $this->comp['comp_name']=$_POST['comp_name'];
           $this->comp['max']=$_POST['max'];
           $this->comp['min']=$_POST['min'];
           $this->Header();
           $this->load->view('web/components/aksc/reg_home',$this->comp);
           $this->Navbar($this->navbar_element);
           $this->load->view('web/components/aksc/askc_com_form',$this->comp);
           $this->Footer();

          }

          /* AFTER SUBMITTING FORM */


          else if(isset($_POST['reg_form_submit'])){

              $uni_name=$_POST['uni-name'];
              $this->comp['max']=$_POST['max_member'];
              $this->comp['min']=$_POST['min_member'];
              $this->comp['comp_name']=$_POST['comp_name'];
              $team_name=$_POST['team-name'];
              $m_name=$_POST['m_name'];
              $m_contact=$_POST['m_contact'];
              $m_nic=$_POST['m_nic']; 
              $m_email=$_POST['m_email'];

              /* VALIDATING FORM DATA
              IF ERROR FOUND THEN IT WILL ADD ERROR MSG INTO FLASH DATA */

              $uni_name_error=validate_data($uni_name);
              if(empty($uni_name_error)){
                   $uni_name_error=validate_names($uni_name);
              }

              if(isset($uni_name_error)){
              $this->comp['uni_name_error']=$uni_name_error;
              $error=true;
            }
    

              /*VALIDATION FOR TEAM NAME*/

              $team_name_error=validate_data($team_name);
              if(empty($team_name_error)){
                 $team_name_error=validate_names($team_name);
              }

              if(isset($team_name_error)){
              $this->comp['team_name_error']=$team_name_error;
              $error=true;
            }

              /*VALIDATION FOR EMAIL ADDRESS*/

              

             if(isset($team_email_error)){
              $this->comp['team_email_error']=$team_email_error;
              $error=true;
            }

             /*LOOP WHICH WILL VALIDATE MEMBERS NAME , NIC AND CONTACT NO*/
             for($i=0;$i<$this->comp['min'];$i++){
                 $m_name_error[$i]=validate_data($m_name[$i]);
                 if(empty($m_name_error[$i])){
                      $m_name_error[$i]=validate_names($m_name[$i]);
                 }

                 if(isset($m_name_error[$i]))
                {
                 $this->comp['m_name_error'][$i]=$m_name_error[$i];
                 $error=true;
                }

                 $m_contact_error[$i]=validate_data($m_contact[$i]);
                 if(empty($m_contact_error[$i])){
                     $m_contact_error[$i]=validate_contact($m_contact[$i]);
                 }

                 if(isset($m_contact_error[$i]))
                {
                 $this->comp['m_contact_error'][$i]=$m_contact_error[$i];
                 $error=true;
               }

                 $m_nic_error[$i]=validate_data($m_nic[$i]);
                 if(empty($m_nic_error[$i])){
                     $m_nic_error[$i]=validate_nic($m_nic[$i]);
                 }

                 if(isset($m_nic_error[$i]))
                 {
                 $this->comp['m_nic_error'][$i]=$m_nic_error[$i];
                 $error=true;
               }
             }


             for($j=$i;$j<$this->comp['max'];$j++){
                 if((!empty($m_name[$j]))||(!empty($m_contact[$j]))||(!empty($m_nic[$j]))){
                   $m_name_error[$j]=validate_data($m_name[$j]);
                   if(empty($m_name_error[$j])){
                        $m_name_error[$j]=validate_names($m_name[$j]);
                   }

                   if(isset($m_name_error[$j]))
                  {
                   $this->comp['m_name_error'][$j]=$m_name_error[$j];
                   $error=true;
                  }

                   $m_contact_error[$j]=validate_data($m_contact[$j]);
                   if(empty($m_contact_error[$j])){
                       $m_contact_error[$j]=validate_contact($m_contact[$j]);
                   }

                   if(isset($m_contact_error[$j]))
                  {
                   $this->comp['m_contact_error'][$j]=$m_contact_error[$j];
                   $error=true;
                 }

                   $m_nic_error[$j]=validate_data($m_nic[$j]);
                   if(empty($team_email_error[$j])){
                       $m_nic_error[$j]=validate_nic($m_nic[$j]);
                   }

                   if(isset($m_nic_error[$j]))
                   {
                   $this->comp['m_nic_error'][$j]=$m_nic_error[$j];
                   $error=true;
                 }
                 }
             }

            $this->Header();
            $this->load->view('web/components/aksc/reg_home',$this->comp);
            $this->Navbar($this->navbar_element);

            if($error){

              $this->load->view('web/components/aksc/askc_com_form',$this->comp);

            }
            else{
                /*LOOP COUNTING TEAM MEMBERS*/
                $team_count=0;
                foreach($m_name as $name){
                   if(!empty($name))  $team_count++;
                }
                 $letter="";
                 $words=explode(" ",$this->comp['comp_name']);
                 foreach($words as $value){
                    $value=strtoupper($value);
                    $letter.=substr($value,0,1);
                 }
                $this->comp['comp_id']=$letter;
                $this->comp['team_name']=$team_name;
                $return_id=$this->aksc_model->insert_reg_record($uni_name,$team_name,$this->comp['comp_id'],$team_count,$m_name,$m_contact,$m_nic,$m_email);
                $return_id=str_pad($return_id,4,"0",STR_PAD_LEFT);
                $this->comp['id']=$return_id;
                $this->load->view('web/components/aksc/aksc_form_resp',$this->comp);
            }

            $this->Footer();





      }
   }
 }

?>

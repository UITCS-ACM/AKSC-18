<?php
  class Acm extends MY_Controller{

    private $title="UITCS-ACM";
    private $data=array();

    private $navbar_element=array(
      'navbar'=>array(
         'HOME'=>'#HOME',
         'ABOUT'=>'#ABOUT',
         'JOIN US'=>'#JOIN',
         'TEAM'=>'#TEAM',
         'EVENTS'=>'#EVENTS',
         'AKSC'=>'http://localhost/uitcs_acm/codeignitor/aksc'
       ),
        'event'=>'ACM',
        'image'=>'logo_burned.png'
    );
 
     public function __construct(){
          parent::__construct($this->title);
          $this->load->helper('url');
          $this->load->model('acm_model');
     }

     /* Function responsible for output the whole acm page
     the index function is default
     In this function we will load other functions of same model */
     public  function index()
     {
              $this->Header();         //function will load the header section
              $this->Home_section(); //function will load home_section slider...
              $this->Navbar($this->navbar_element);
              $this->About_us();       //function will load about_us Section
              $this->Join_us();        //function will load join_us
              $this->Team();           //function will load team
              $this->Events();        //function will load events Section
              $this->Contact();       //function will load contact us Section
              $this->Footer();        //function will load footer of page
     }

     
     private function Home_section(){
           //$this->load->model_name('');           Will Uncomment this line when DB is completely setup

           $this->load->view('web/components/acm/acm_page_home');
     }


     private function About_us()
     {
              //$this->load->model_name('');           Will Uncomment this line when DB is completely setup

              $this->load->view('web/components/acm/acm_page_about');
     }

     private function Join_us()
     {
              //$this->load->model_name('');           Will Uncomment this line when DB is completely setup

              $this->load->view('web/components/acm/acm_page_join');
     }

     private function Team()
     {
              $table="team";
              $this->data['team']=$this->acm_model->get_all($table);
              $this->load->view('web/components/acm/acm_page_team',$this->data);
     }

     private function Events()
     {
              //$this->load->model_name('');           Will Uncomment this line when DB is completely setup
              $table="events";
              $this->data['events']=$this->acm_model->get_all($table);
              $this->load->view('web/components/acm/acm_page_events',$this->data);
     }


     private function load_model($id)
     {

        $this->data['person_data']=$this->acm_model->get_all();
     }





  }
?>`

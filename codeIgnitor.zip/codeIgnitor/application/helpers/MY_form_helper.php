<?php

/* FUNCTION WHICH WILL VALIDATE FORM DATA */

function validate_data($data)
{
    if(empty($data)){
         $error="Field must contain value";
         return $error;
    }

    $data=trim($data);
    $data=htmlspecialchars($data);
}


function validate_names($name)
{
    $match="/^[A-Za-z\s]+$/";
    if(!preg_match($match,$name)){
        return "Please Enter only alphabets";
    }
}


function validate_email($email)
{
        $match="/^[\w]+@[a-zA-Z]+\.[a-z]{3}$/";

        if(!preg_match($match,$email)){
            return "Email is not valid";
        }
}


function validate_contact($number){
      $match="/^03[0-9]{2}-?[0-9]{7}$/";

      if(!preg_match($match,$number)){
        return "Field should contain only numbers";
      }
}


function filter_name($data){

     $data=trim($data);
     $data=htmlspecialchars($data);
     return $data;
}


function validate_nic($nic){
     $match="/^[0-9]{5}-?[0-9]{7}-?[0-9]$/";

     if(!preg_match($match,$nic)){
       return "Enter Valid NIC Number";
     }
}
/*FUNCTION FOR VALIDATING IMAGES */
function validate_image($event_image_name,$event_image_type,$event_image_temp,$event_image_error,$type=null){


      $type=array("image/jpeg","image/png","image/jpg","video/mp4","video/webm","video/ogg");

      if($event_image_error>0){

         switch($event_image_error){
            case 1:
            return "File exceeded Upload Max File Size";
            break;

            case 2:
            return "File exceeded max_file_size";
            break;

            case 3:
            return "File only partially uploaded";
            break;

            case 4:
            return "No file uploaded";
            break;

            case 6:
            return "Cannot upload file: No temp directory specified";
            break;

            case 7:
            return "Upload file can't write to disk";
            break;

            case 8:
            return "A PHP extension blocked the file upload";
            break;

            default:
            return $user_image_error." error";
            break;
    }
  }
  if(!in_array($event_image_type,$type))        //CHECKING THAT IMAGE IS OF VALID TYPE OF not
        return "Invalid Image Type.";

  if(is_uploaded_file($event_image_temp)){
     $upload_path='D:/wamp64/www/uitcs_acm/codeignitor/assets/website/images/'.$event_image_name;
       if(!(move_uploaded_file($event_image_temp,$upload_path)))
           return "Unable to move file";
  }
}



?>

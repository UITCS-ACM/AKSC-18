<!DOCTYPE HTML>
<html lang="en">
<head>
<title>UITCS ACM</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width , initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/website/css/style.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="type/images" id="fevicon" href="../images/logo_burned.png">
<link rel="stylesheet" href="<?php echo base_url();?>assets/website/owlcarousel/assets/owl.carousel.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/website/owlcarousel/assets/owl.theme.default.min.css">
<link href="https://fonts.googleapis.com/css?family=Raleway|Open+Sans" rel="stylesheet">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="<?php echo base_url();?>assets/website/js/file.js"></script>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-111755194-1"></script>
<script src="<?php echo base_url();?>assets/website/owlcarousel/owl.carousel.min.js"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-111755194-1');
</script>
</head>

<div class="container-fluid past-events" id="EVENTS">
  <h1 class="text-center main-heading">EVENTS</h1>
  <!-- Set up your HTML -->
<div class="owl-carousel owl-theme">
<?php
     if($events->num_rows>0){
  while($row=$events->fetch_assoc()){
?>
<div class="carousel-item">
  <div class="event">
     <div class="event-img">
       <img src="<?php echo base_url();?>assets/website/images/<?php echo $row['event_image'];?>" alt="" height="250px" width="200px">
     </div>
      <div class="event-content">
         <h3><?php echo $row['event_name'];?></h3>
         <p><?php echo date('d-M-Y',strtotime($row['date']));?></p>
         <p><?php echo $row['event_des'];?></p>
      </div>
  </div>
</div>
<?php
}
 }
else{
    echo "No Past Event Available";
}
?>
</div>
</div>

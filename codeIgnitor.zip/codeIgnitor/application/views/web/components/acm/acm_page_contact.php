<!--Contact Us-->
<div class="container-fluid contact-us" id="CONTACT">
          <div class="outer-div"><div class="heading text-center"><h1>GET IN TOUCH</h1></div></div>
        <div class="container">
            <div class="row contact-row">
               <div class="col-sm-6">
                   <form action="somefile.php" method="post">
                       <div class="form-group">
                           <input type="text" class="form-control" placeholder="Name" name="full-name" id="name" required >
                       </div>
                       <div class="form-group">
                           <input type="email" class="form-control" placeholder="Email" name="email" id="email" required>
                       </div>
                       <div class="form-group">
                           <textarea name="comment" id="comment" cols="30" rows="10" class="form-control" placeholder="What's on your mind" required></textarea>
                       </div>
                       <div class="form-group">
                           <button class="form-control btn btn-default" type="submit">SUBMIT</button>
                       </div>
                   </form>
               </div>
               <div class="col-sm-6 get-in-touch">
                   <div class="row">
                       <h3>Getting in Touch is easey!</h3>
                   </div><br><br>
                   <div class="row">
                       <strong><i class="fa fa-map-marker"></i> VISIT US:</strong>
                       <small>ST-13, Block 7, Gulshan-e-Iqbal, Abul Hasan Isphahani Road, Karachi, Pakistan.</small>
                   </div>
                   <div class="row">
                        <strong><i class="fa fa-phone"></i> CALL US:</strong>
                        <small>+92 324 3280750 Monday–Friday | 9am–5pm (GMT +5)</small>
                   </div>
                   <div class="row">
                        <strong><i class="fa fa-envelope"></i> EMAIL:</strong>
                        <small>uitcs@example.com</small>
                   </div>
                   <div class="row"><hr></div>
                   <div class="row">
                        <div class="col-xs-2 social facebook" id="social-margin">
                            <i class="fa fa-facebook" style="color:white;"></i>
                        </div>
                        <div class="col-xs-2 social instagram">
                              <i class="fa fa-instagram" style="color:white;"></i>
                        </div>
                        <div class="col-xs-2 social twitter">
                            <i class="fa fa-twitter" style="color:white;"></i>
                      </div>
                      </div>
               </div>
            </div>
         </div>
         <div class="container">
            <div class="map-row">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title" data-toggle="collapse" data-target="#map">LOCATE US ON MAP <i class="fa fa-angle-down"></i></h3>
                    </div>
                    <div class="collapse panel-collapse" id="map">
                      <div class="panel-body">
                            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3618.1220773444047!2d67.1065453149211!3d24.927910848690242!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3eb338c700571b09%3A0xd86779b29e77f36a!2sUsman+Institute+of+Technology!5e0!3m2!1sen!2s!4v1513489903405" width="100%" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
                      </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<div class="container-fluid team" id="TEAM">
	<h1 class="text-center">TEAM</h1>
	<div class="line"></div>
	<div class="text-center row team-tagline">
		<h4>We’re led by a team who constantly questions, tinkers, and challenges to unlock great creativity around every turn.</h4>
	</div>
	<div class="container members-div">
		<?php if($team->num_rows>0){    /* PHP TAG WHILE LOOP FOR LOOP THROUGH ALL TEAM MEMBER */
              while($row=$team->fetch_assoc()){
             echo "<div class='row text-center'>";

                 for($i=0;$i<4;$i++){  /* SECOND LOOP FOR SHOW THE TEAM IN ROW */
              ?>
		<div class="col-sm-6 col-md-3">
			<div class="team-mate-image">
				<img src="<?php echo base_url();?>assets/website/images/<?php echo $row['image'];?>" alt="<?php echo $row['name'];?>" class="img-responsive">
			</div>
			<a href="#<?php echo $row['id'];?>" data-toggle="modal">
				<div class="link-icon">
					<i class="fa fa-long-arrow-right"></i>
				</div>
			</a>
			<div class="team-mate-content">
				<div class="background-shade">
					<div class="front-content">
						<?php echo $row['name'];?>
					</div>
					<div class="designation">
						<?php echo $row['designation'];?>
					</div>
				</div>
			</div>
		</div>
		<?php
                     if($i<3) $row=$team->fetch_assoc();
                 }
                  }         /* CLOSING OF LOOP */
                $team->data_seek(0);         //POINTING AGAIN TO TOP
                }/* CLOSING OF IF CONDITION  */?>
	</div>
</div>
</div>
<div class="container">
	<?php if($team->num_rows>0){
         while($row=$team->fetch_assoc()){
     ?>
	<div class="modal fade" id="<?php echo $row['id'];?>" role="dialog">
		<div class="modal-dialog modal-lg">
			<div class="modal-content row">
				<div class="col-sm-4 member-image">
					<img src="<?php echo base_url();?>assets/website/images/<?php echo $row['image'];?>" alt="<?php echo $row['name'];?>">
				</div>
				<div class="col-sm-8">
					<div class="modal-header">
						<div class="close-btn close" data-dismiss="modal">
							<span class="text-center close-icon">&times;</span>
						</div>
						<div class="modal-title">
							<h2><?php echo $row['name'];?><br> <small><?php echo $row['designation'];?></small></h2>

						</div>
						<div class="row">
							<a href="<?php echo $row['fblink']?>;">
								<div class="col-xs-2 social facebook" id="social-margin">
									<i class="fa fa-facebook" style="color:white;"></i>
								</div>
							</a>
							<a href="<?php echo $row['glink']?>;">
								<div class="col-xs-2 social instagram">
									<i class="fa fa-instagram" style="color:white;"></i>
								</div>
							</a>
							<a href="<?php echo $row['tlink']?>;">
								<div class="col-xs-2 social twitter">
									<i class="fa fa-twitter" style="color:white;"></i>
								</div>
							</a>
						</div>
					</div>
					<div class="modal-body">
						<p>
							<?php echo $row['description'];?>
						</p>
					</div>
				</div>
			</div>
		</div>
	</div>
	<?php
       }
   } ?>
</div>
</div>

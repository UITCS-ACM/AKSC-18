  <div class="container  acm-about-us" id="ABOUT">
        <div class="row">
            <h1 class="text-center" id="about-us-heading">ABOUT US</h1>
            <div class="line"></div>
            <div class="text-center row team-tagline">
		<h4>We’re led by a team who constantly questions, tinkers, and challenges to unlock great creativity around every turn.</h4>
            </div>
            <div class="col-sm-6">
                <h3>Who we are ?</h3>
                <p>UITCS – UIT Computer Society an active student chapter of ACM – Association for Computing Machinery, 
                    we are extremely engulfed in promoting interest in the IT society. We also provides platforms for the ones 
                    who are thriving to quench their thirst in the techno society. UITCS-ACM is collaboration of the team work of 
                    faculty members and
                     students volunteers in order to achieve the fruitful result in innovation and technology</p>
            </div>

             <div class="col-sm-6">
                   <img src="<?php echo base_url(); ?>assets/website/images/collage.jpg" class="img-responsive" alt="about-collage"> >
                </div>
        </div>
        
    </div>

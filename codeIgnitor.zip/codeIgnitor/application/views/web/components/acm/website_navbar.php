<?php
  defined('BASEPATH')  OR exit('No direct script access allowed');
?>

  <div class="container menu">
		<nav class="navbar navbar-default homepage-navbar navbar-fixed-top" id="home-navbar">
			<div class="container">
				<div class="navbar-header">
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
										<span class="icon-bar"></span>
										<span class="icon-bar"></span>
										<span class="icon-bar"></span>
								</button>
					 <a class="navbar-brand"><img src="<?php echo base_url();?>assets/website/images/<?php echo $image;?>" class="img-responsive" alt="<?php echo $event;?>"></a>
				</div>
				<div class="collapse navbar-collapse" id="myNavbar">
          <ul class="nav navbar-nav navbar-right home-page-navbar-ul">
             <?php foreach($navbar as $key=>$value)
             {
                ?>
              <li class="<?php if(strpos($value,'HOME')!==false) echo 'active';?>"><a href="<?php echo $value;?>"><?php echo $key;?></a></li>
              <?php
            }
            ?>
          </ul>
				</div>
			</div>
		</nav>
	</div>

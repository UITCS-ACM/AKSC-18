<div class="container-fluid join-us" id="JOIN">
       <div class="container">
            <h2 class="text-center " id="join-us-heading">Want to connect with us. Look on the reasons</h2>
        <div class="row about-us row-eq-height">
           
           
         <div class="join-us-content">
            <div class="col-sm-4">
             <div class="join-us-card">
                <h3>BENEFITS OF ACM</h3>
                  <p class=" join-us-inner-content">There are many reasons to join ACM. When you become a member, you become a part of the dynamic changes that are transforming our world, by helping to shape the future of computing. ACM provides the tools and resources to help get you there, by advancing your career and enriching your knowledge with life-long learning resources connecting with your community and making it a better place.</p>
            </div>
        </div>
            <div class="col-sm-4">
                    <div class="join-us-card">
              <h3>WHY VOLUNTEER?</h3>
                   <p class=" join-us-inner-content">Volunteering at UITCS enables you to learn new skills, put those you have already learnt into practice and get great references too. Through volunteering you get to meet and participate in interacting activities with like-minded people. Volunteering allows you to help make change in something you are passionate about while connecting with your community and making it a better place.</p>
            </div>
        </div>
             <div class="col-sm-4">
                    <div class="join-us-card">
                    <h3>WHAT WE DO</h3>
                   <p class=" join-us-inner-content">UITCS-ACM Student Chapter organized the largest national and international conferences ideally, multi-topic competitions, exhibitions, and other events addressed as UATCC - UITCS ACM Technical Conference on Computing, UTECH and interacting events like Technowave and ICC-UIT. These events instigated a whole new dimension of IT by organizing more than 8 divergent competitions.</p>
            </div>
        </div>
        </div>
        </div>
        </div>
    </div>

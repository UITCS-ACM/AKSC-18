<div class="container sponsors" id="SPONSORS">
         <h1 class="text-center">SPONSORS AND PARTNERS</h1>
         <div class="line"></div>
        <div class="row">
            <hr>
           <div class="col-sm-3 text-center">
               <h5 class="text-center">PLATINUM SPONSORS</h5>
               <img src="<?php echo base_url();?>assets/website/images/palekar.png" alt="Palekar Foods" width="150px" height="150px">
           </div>
           <div class="col-sm-3 text-center">
                <h5 class="text-center">GOLD SPONSORS</h5>
                <img src="<?php echo base_url();?>assets/website/images/7Grandee.jpg" alt="Palekar Foods" width="150px" height="150px">
           </div>
           <div class="col-sm-3 text-center">
                <h5 class="text-center">SILVER SPONSORS</h5>
                <img src="<?php echo base_url();?>assets/website/images/gearit.jpg" alt="Palekar Foods" width="150px" height="150px">
           </div>
           <div class="col-sm-3 text-center">
                <h5 class="text-center">BRONZE SPONSORS</h5>
                <img src="<?php echo base_url();?>assets/website/images/totalsolution.png" alt="Palekar Foods" width="150px" height="150px">
           </div>
        </div>
        <hr>
    </div>

<div class="container-fluid competition" id="COMPETITIONS">
	<h1 class="text-center">COMPETITIONS</h1>
	<div class="line"></div>
	<div class="container">
	<?php
	  if($result->num_rows>0){
	    while($row=$result->fetch_assoc()){
       ?>
		<div class="row  competition-row">
		  <?php
		      for($i=0;$i<4;$i++){
        ?>
			<div class="col-sm-3">
				<div class="competition-div-outline">
					<div class="text-center competition-div">
						<i class="fa <?php echo $row['icon']; ?> fa-3x cd-icon"></i>
						<h4><?php echo strtoupper($row['comp_name']); ?></h4>
						<p><?php echo $row['tag_line']; ?> </p>
						<a href="#<?php echo strtok($row['comp_name']," ");?>" data-toggle="modal"><button class="btn btn-info comp-reg" type="submit" data-toggle="modal" data-taget="#modal">Register</button></a>
					</div>
				</div>
			</div>
			<?php
			if($i<3)
			    $row=$result->fetch_assoc();
			  }

			?>
			<!-- end of while loop -->
		</div>
	  <?php
		}
		$result->data_seek(0);
	}
	  ?>
	</div>

</div>
<!-- MODAL  -->
<?php
   while($row=$result->fetch_assoc())
   {
?>
<div class="modal fade" id="<?php echo strtok($row['comp_name']," ");?>" tabindex="-1" role="dialog">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" data-dismiss="modal" class="close">&times;</button>
				<h1 class="modal-title text-center"><?php echo strtoupper($row['comp_name']);?></h1>
			</div>
			<div class="modal-body">
				<div>
					<div class="row">
					   <?php
					       echo $row['description'];
					   ?>
					</div><br />

					<div class="row">
            <h3>Rules And Regulation</h3><?php echo $row['rules'];?>
					</div>

					<div class="row">
            <h3>Registration: </h3>
						Maximum members per team: <?php echo $row['max_member']." Rs.".$row['price']; ?> /- per person
					</div>

					<div class="row">
            <h3>Elgibility Criteria</h3><?php echo $row['eligiblity'];?>
					</div>

					<div class="row">
            <h3>Winning Criteria</h3>
						<?php echo $row['winning_criteria'];?>
					</div>
				</div>
			</div>
			<div class="modal-footer">
				<form action="<?php echo base_url().'aksc/Reg_Form';?>" method="post">
				    <input type="hidden" name="comp_name" value="<?php echo $row['comp_name']; ?>">
					<input type="hidden" name="max" value="<?php echo $row['max_member']; ?>" >
					<input type="hidden" name="min" value="<?php echo $row['min_member']; ?>">
				   <button class="btn btn-primary" name="register">Register</button>
				</form>
			</div>
		</div>
	</div>
</div>
<?php
}
   ?>

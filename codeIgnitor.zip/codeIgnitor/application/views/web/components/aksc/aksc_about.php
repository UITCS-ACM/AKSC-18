<div class="container-fluid aksc-about" id="ABOUT">
        <div class="row">
            <div class="col-sm-6 aksc-about-video">
               <video src="<?php echo base_url();?>assets/website/images/ACM Karachi Student Congress 2016 Promo Vedio - YouTube.mp4" width="100%" autoplay muted loop></video>
            </div>
            <div class="col-sm-6 aksc-about-content">
                <h1 id="aksc-about-heading">BIG THINGS ARE COMING</h1>
                <p> Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing
                     software like Aldus PageMaker including versions of Lorem Ipsum.</p>
                <button class="btn btn-primary comp-reg" type="submit">REGISTER</button>
            </div>
        </div>
    </div>

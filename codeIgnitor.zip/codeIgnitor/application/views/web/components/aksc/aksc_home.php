<body>
	<div class="container-fluid aksc" id="HOME">
		<div class="row">
			<div class="aksc-homepage">
				<div class="aksc-video-container">
					<video src="<?php echo base_url();?>assets/website/images/ACM Karachi Student Congress 2016 Promo Vedio - YouTube.mp4" id="aksc-home-video" muted loop autoplay></video>
				</div>
				<div class="aksc-video-shade">
					<div class="aksc-homepage-content text-center">
						<div class="row aksc-main-heading">
							<div class="col-xs-4 text-right">
								<img src="<?php echo base_url();?>assets/website/images/aksc-logo.png" alt="LOGO" width="200px" class="img-responsive">
							</div>
							<div class="col-xs-8 text-left">
								<h1>AKSC'17</h1>
							</div>
						</div>
						<div class="row">
							<p>#LET THE FIRE BEGIN</p>
						</div>
						<div class="mouse-scroll">
							<div class="scroll"></div>
						</div>
					</div>
     </div>
</div>
		</div>
	</div>
	<div class="container-fluid time">
		<div class="row">
      <div class="col-sm-6 event-date">
			<h2>26,27 December 2017</h2>
			<h2>Starting at 8 am</h2>
      </div>
      <div class="col-sm-6 remaining-days">
         <span><h3 id="days">23</h3> DAYS</span>
         <span><h3 id="hours">23</h3> HOURS</span>
         <span><h3 id="minutes">23</h3> MINUTES</span>
         <span><h3 id="seconds">23</h3> SECONDS</span>
      </div>
		</div>
	</div>

<?php
defined('BASEPATH') OR exit('No Direct script access allowed');
?>

<div class="container-fluid">
    <h1 class="text-center" style="margin-top:70px;">REGISTRATION DETAILS</h1>
    <div class="line"></div>

    <div class="container form-msg">
       <div class="row">
              <p>Congratulations! You have successfully registered at AKSC'18</p>
              <p>Your registration details are: </p>
              <p>TEAM ID: <strong  class="blue"><?php echo $comp_id.$id; ?></strong></p>
               <p>TEAM NAME: <strong  class="blue"><?php echo $team_name;?></strong></p>
               <p>EVENT NAME: <strong  class="blue"><?php echo $comp_name;?></strong></p>
       </div>
       <div class="row">
           <h4 class="blue">WHAT'S NEXT</h4> You can get ticket from:
              <br />
              <p><strong>OUR CAMPUR AMBASADOR: </strong> <a href="">FACEBOOK</a> PAGE</p>
       </div>
    </div>
</div>

<?php
defined('BASEPATH') OR exit('No Direct Script Access Allowed');
?>


	<div class="container-fluid com-reg-form">
		<h1 class="text-center">REGISTRATION</h1>
		<div class="line"></div>

		<div class="container com-form">
			<form action="<?php echo base_url();?>aksc/Reg_Form" method="post" class="form-horizontal">
			 <input type="hidden" name="max_member" value="<?php echo $max;?>">
			 <input type="hidden" name="min_member" value="<?php echo $min; ?>">
			 <input type="hidden" name="comp_name" value="<?php echo $comp_name;?>">
				<div class="form-group">
					 <div class="col-sm-4">
						<input type="text" name="uni-name" id="uni-name" class="form-control" placeholder="University Name" required><span class="warning" style="color:red;"><?php if(isset($uni_name_error)) echo $uni_name_error; ?></span>
					</div>
					 <div class="col-sm-4">
					    <input type="text" class="form-control" name="team-name" id="team-name" placeholder="Team Name" required><span class="warning" style="color:red;"><?php if(isset($team_name_error)) echo $team_name_error; ?></span>
					  </div>
				</div>
			 <?php for($i=0;$i<$max;$i++){           /* LOOP DISPLAY THE FORM
			                                         AND INSERTING REQUIRED FIELD ON MINI MEMBERS FIEDLS */
			  ?>
			    <input type="hidden" name="member<?php echo $i+1;?>" value="member<?php echo $i+1;?>">
				<div class="form-group">
					<div class="col-sm-3">
						<input type="text" name="m_name[]" id="m<?php echo $i+1; ?>_name" class="form-control" placeholder="Team Member Name" <?php echo $i<$min?'required':'';?>><span class="warning" style="color:red;"><?php if(isset($m_name_error[$i])) echo $m_name_error[$i]; ?></span>
					</div>
					<div class="col-sm-3">
						<input type="text" name="m_contact[]" id="m<?php echo $i+1; ?>_contact" class="form-control" placeholder="Team Member Contact"  <?php echo $i<$min?'required':'';?>><span class="warning" style="color:red;"><?php if(isset($m_contact_error[$i])) echo $m_contact_error[$i]; ?></span>
					</div>
					<div class="col-sm-3">
						<input type="text" class="form-control" name="m_nic[]" id="m<?php echo $i+1; ?>_nic" placeholder="Team Member NIC"  <?php echo $i<$min?'required':'';?>><span class="warning" style="color:red;"><?php if(isset($m_nic_error[$i])) echo $m_nic_error[$i]; ?></span>
					</div>
					<div class="col-sm-3">
					  <input type="email" class="form-control" name="m_email[]" id="m<?php echo $i+1;?>_email" placeholder="Team Member Email" <?php echo $i<$min?'required':''; ?>><span class="warning" style="color:red;"><?php if(isset($m_email_error[$i])) echo $m_email_error[$i]; ?></span>
					</div>
				</div>
				<?php
			}
				?>

				<div class="form-group text-center">
				   <button class="btn btn-primary" type="submit" name="reg_form_submit">Submit</button>
				</div>
			</form>
		</div>
	</div>

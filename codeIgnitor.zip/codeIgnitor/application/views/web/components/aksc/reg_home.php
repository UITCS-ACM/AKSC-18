<body>
   
    <div class="container-fluid reg_home">
      <div class="row content">
         <div class="inner-content text-center">
             <div class="com-heading text-center">
                <h1><?php echo strtoupper($comp_name); ?></h1>
             </div>
             <div class="tag-line">
               <h3>#LET THE FIRE BEGIN</h3>
             </div>
             <ul class="comp-points">
                <li><h4>Note:</h4></li>
                <li>Fill all required Feilds</li>
               <li>Minimum <?php echo $min; ?>, Maximum <?php echo $max; ?> members</li>
               <li>Provide active email address</li>
             </ul>         
         </div>
  </div>
</div>
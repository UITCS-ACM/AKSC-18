<nav class="navbar navbar-default aksc-navbar">
     <div class="container">
         <div class="navbar-header">
            <button class="navbar-toggle" type="button" data-toggle="collapse" data-target="#aksc-navbar">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
           <a href="#" class="navbar-brand"><img src="<?php echo base_url();?>assets/website/images/aksc-logo.png" alt="AKSC-LOGO" class="img-responsive" width="40px"></a>
         </div>
       <div class="collapse navbar-collapse" id="aksc-navbar">
          <ul class="nav navbar-nav navbar-right">
              <li class="active"><a href="">HOME</a></li>
              <li><a href="">ABOUT</a></li>
              <li><a href="">COMPEITITIONS</a></li>
              <li><a href="">CONTACT</a></li>
          </ul>
       </div>
     </div>
</nav> 

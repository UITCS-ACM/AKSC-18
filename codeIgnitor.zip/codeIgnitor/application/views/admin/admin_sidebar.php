
<div class="container-fluid">
<div class="row">

<ul class="nav nav-pills nav-stacked side-menu col-sm-2">
        <li><a href="">
         <img src="<?php echo base_url();?>assets/website/images/shariq.jpg" alt="admin-img" width="40px" class="img-circle"> Muhammad Shariq
        </a></li>
        <li><a href="">
          <form action="somfile">
            <div class="input-group">

                <input type="text" class="form-control" id="search" name="search" placeholder="Search">
                <span class="input-group-addon"><i class="fa fa-search"></i></span>
            </div>
        </form>
        </a></li>
        
        <li><a href="<?php echo base_url();?>admin/dashboard"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li><a href="<?php echo base_url();?>admin/competition" target="_blank">Competition</a></li>
        <li><a href="<?php echo base_url();?>admin/team">Team</a></li>
        <li><a href="<?php echo base_url();?>admin/events"><i class="fa fa-calendar-alt"></i> Events</a></li>
        <li><a href="<?php echo base_url(); ?>admin/media"><i class="fa fa-th"></i> Media Manager</a></li>
        <li><a href="<?php echo base_url();?>admin/sponsors">Sponsors</a></li>
        
    
    </ul>

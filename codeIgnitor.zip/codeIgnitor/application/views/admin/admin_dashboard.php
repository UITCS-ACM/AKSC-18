<div class="col-sm-10">
            <div class="container-fluid">
                <h2>Dashboard</h2><br><br>
                <div class="row">
                    <div class="col-sm-5">
                        <div class="panel-group">
                            <div class="panel panel-default">
                                <div class="panel-heading">Quick Draft <a href="#panel-collapse" data-toggle="collapse"><i class="fa fa-minus pull-right"></i></a></div>
                              <div class="collapse in" id="panel-collapse">
                                  <div class="panel-body">
                                      <form action="somfile.php" method="post">
                                          <div class="form-group">
                                              <input type="text" class="form-control" name="draft-title" id="draft-title" placeholder="Title" required>
                                          </div>
                                          <div class="form-group">
                                             <textarea name="draft-text" id="draft-text" cols="30" rows="5" class="form-control" placeholder="What's on your mind?" required></textarea>
                                          </div>
                                          <div class="form-group">
                                              <button class="btn btn-primary" type="submit" name="save-draft" >Save Draft</button>
                                          </div>
                                      </form>
                                  </div>
                              </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-7">
                        <div class="panel-group">
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    Visitors   <a href="#visitors-panel" data-toggle="collapse"><i class="fa fa-minus pull-right"></i></a>
                                </div>
                                <div class="collapse in" id="visitors-panel">
                                    <div class="panel-body">
                                        <iframe width="100%" height="371px" seamless frameborder="0" scrolling="no" src="https://docs.google.com/spreadsheets/d/e/2PACX-1vTd7Yebrw_6ExTJyDGxn_sDQrp_fNeyG7E0GDuzQq80fVECy2daaWHWBuoHmOn-5alzYzZsBT9h-lyD/pubchart?oid=592843660&amp;format=interactive"></iframe>
                                    </div>
                                </div>
                            </div>
                        </div>
                       
                    </div>
                </div>
            </div>
        </div>
  </div>
  </div>
  </div>
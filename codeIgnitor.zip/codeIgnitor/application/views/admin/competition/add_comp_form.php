<div class="" id="add-comp">
   <form action="" method="POST">
       <div class="form-group">
           <div class="col-sm-4">
               <label for="comp_name">Competition Name:*</label>
               <input type="text" class="form-control" name="comp_name" id="comp_name" placeholder="Compeition Name" required><span class="error"></span>
           </div>
           <div class="col-sm-4">
            <label for="comp_name">Tag-Line:*</label>
            <input type="text" class="form-control" name="tag_line" id="tag_line" placeholder="Tag Line" required><span class="error"></span>
           </div>
           <div class="col-sm-4">
            <label for="comp_name">:*</label>
            <input type="text" class="form-control" name="" id="" placeholder="Compeition Name" required><span class="error"></span>
           </div>
       </div>
   </form>
</div>
<!doctype html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width , initial-scale=1">
        <link rel="stylesheet" href="<?php echo base_url();?>assets/website/css/bootstrap.min.css">
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/website/css/font-awesome.min.css">
        <link rel="stylesheet" href="<?php echo base_url();?>assets/admin/css/admin-stylesheet.css">
        <link rel="type/images" id="fevicon" href="../images/logo_burned.png">
        <script src="<?php echo base_url();?>assets/website/js/jquery.js"></script>
        <script src="http://malsup.github.com/jquery.form.js"></script>

        </script>
        <script type="text/javascript" src="<?php echo base_url();?>assets/website/js/bootstrap.bundle.js"></script>
        <script src="<?php echo base_url();?>assets/website/js/bootstrap.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url();?>assets/admin/js/event_model.js"></script>
        <script type="text/javascript" src="<?php echo base_url();?>assets/admin/js/file.js"></script>
        <script type="text/javascript" src="<?php echo base_url();?>assets/admin/js/team.js"></script>
    </head>
    <body>

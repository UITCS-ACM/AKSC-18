-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 24, 2019 at 07:30 PM
-- Server version: 5.7.14
-- PHP Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `acm`
--

-- --------------------------------------------------------

--
-- Table structure for table `competitions`
--

CREATE TABLE `competitions` (
  `id` int(11) NOT NULL,
  `comp_name` varchar(100) NOT NULL,
  `tag_line` varchar(255) NOT NULL,
  `icon` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `rules` text NOT NULL,
  `max_member` int(11) NOT NULL,
  `min_member` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `eligiblity` text NOT NULL,
  `winning_criteria` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `competitions`
--

INSERT INTO `competitions` (`id`, `comp_name`, `tag_line`, `icon`, `description`, `rules`, `max_member`, `min_member`, `price`, `eligiblity`, `winning_criteria`) VALUES
(1, 'Speed Programming', 'Registration is open for 2018 Conference', 'fa-code', 'This competition will Test your skills in Complex Maths, algebric-equation based problems, which will be solved using the complexity of BODMAS Rules. The competition is designed to evaluate conceptual knowledge, basic understanding and logical interpretation ability of students. Our objective is to identify and promote mathematical genius.', 'There will be two rounds in competition. First round Around 50 MCQ’s and the duration time is 25 mints. Then we have 30 mints break. In second round includes 50 MCQ’s plus 10 questions and the duration time will be of 50 mints. There will be no negative marking. After the examination, the candidates would have to return both the Question booklet and the Answer sheet to the invigilator. Message will be sent to winning team’s heads only. The overall time of the Competition is around 2 hours. In second round, Non programmable Calculator will be allowed. There will be maximum 1 member in each team.', 3, 1, 500, 'The participant must be enrolled as an undergraduate in any recognized Institute/University. The participant should not be affiliated with organizing or management of this event.', 'Team with the most correct answers will be declared as winner.'),
(2, 'Debug Police', 'Registration is open for 2018 Conference', 'fa-bug', 'This competition will Test your skills in Complex Maths, algebric-equation based problems, which will be solved using the complexity of BODMAS Rules. The competition is designed to evaluate conceptual knowledge, basic understanding and logical interpretation ability of students. Our objective is to identify and promote mathematical genius.', 'There will be two rounds in competition. First round Around 50 MCQ’s and the duration time is 25 mints. Then we have 30 mints break. In second round includes 50 MCQ’s plus 10 questions and the duration time will be of 50 mints. There will be no negative marking. After the examination, the candidates would have to return both the Question booklet and the Answer sheet to the invigilator. Message will be sent to winning team’s heads only. The overall time of the Competition is around 2 hours. In second round, Non programmable Calculator will be allowed. There will be maximum 1 member in each team.', 3, 2, 500, 'The participant must be enrolled as an undergraduate in any recognized Institute/University. The participant should not be affiliated with organizing or management of this event.', 'Team with the most correct answers will be declared as winner.'),
(3, 'Math Genius', 'Registration is open for 2018 Conference', 'fa-lightbulb-o', 'This competition will Test your skills in Complex Maths, algebric-equation based problems, which will be solved using the complexity of BODMAS Rules. The competition is designed to evaluate conceptual knowledge, basic understanding and logical interpretation ability of students. Our objective is to identify and promote mathematical genius.', 'There will be two rounds in competition. First round Around 50 MCQ’s and the duration time is 25 mints. Then we have 30 mints break. In second round includes 50 MCQ’s plus 10 questions and the duration time will be of 50 mints. There will be no negative marking. After the examination, the candidates would have to return both the Question booklet and the Answer sheet to the invigilator. Message will be sent to winning team’s heads only. The overall time of the Competition is around 2 hours. In second round, Non programmable Calculator will be allowed. There will be maximum 1 member in each team.', 3, 1, 500, 'The participant must be enrolled as an undergraduate in any recognized Institute/University. The participant should not be affiliated with organizing or management of this event.', 'Team with the most correct answers will be declared as winner.'),
(4, 'Database Designing', 'Registration is open for 2018 Conference', 'fa-database', 'This competition will Test your skills in Complex Maths, algebric-equation based problems, which will be solved using the complexity of BODMAS Rules. The competition is designed to evaluate conceptual knowledge, basic understanding and logical interpretation ability of students. Our objective is to identify and promote mathematical genius.', 'There will be two rounds in competition. First round Around 50 MCQ’s and the duration time is 25 mints. Then we have 30 mints break. In second round includes 50 MCQ’s plus 10 questions and the duration time will be of 50 mints. There will be no negative marking. After the examination, the candidates would have to return both the Question booklet and the Answer sheet to the invigilator. Message will be sent to winning team’s heads only. The overall time of the Competition is around 2 hours. In second round, Non programmable Calculator will be allowed. There will be maximum 1 member in each team.', 2, 2, 500, 'The participant must be enrolled as an undergraduate in any recognized Institute/University. The participant should not be affiliated with organizing or management of this event.', 'Team with the most correct answers will be declared as winner.'),
(5, 'Logic Bee', 'Registration is open for 2018 Conference', 'fa-microchip', 'This competition will Test your skills in Complex Maths, algebric-equation based problems, which will be solved using the complexity of BODMAS Rules. The competition is designed to evaluate conceptual knowledge, basic understanding and logical interpretation ability of students. Our objective is to identify and promote mathematical genius.', 'There will be two rounds in competition. First round Around 50 MCQ’s and the duration time is 25 mints. Then we have 30 mints break. In second round includes 50 MCQ’s plus 10 questions and the duration time will be of 50 mints. There will be no negative marking. After the examination, the candidates would have to return both the Question booklet and the Answer sheet to the invigilator. Message will be sent to winning team’s heads only. The overall time of the Competition is around 2 hours. In second round, Non programmable Calculator will be allowed. There will be maximum 1 member in each team.', 2, 1, 500, 'The participant must be enrolled as an undergraduate in any recognized Institute/University. The participant should not be affiliated with organizing or management of this event.', 'Team with the most correct answers will be declared as winner.'),
(6, 'Logic Quiz', 'Registration is open for 2018 Conference', 'fa-github-alt', 'This competition will Test your skills in Complex Maths, algebric-equation based problems, which will be solved using the complexity of BODMAS Rules. The competition is designed to evaluate conceptual knowledge, basic understanding and logical interpretation ability of students. Our objective is to identify and promote mathematical genius.', 'There will be two rounds in competition. First round Around 50 MCQ’s and the duration time is 25 mints. Then we have 30 mints break. In second round includes 50 MCQ’s plus 10 questions and the duration time will be of 50 mints. There will be no negative marking. After the examination, the candidates would have to return both the Question booklet and the Answer sheet to the invigilator. Message will be sent to winning team’s heads only. The overall time of the Competition is around 2 hours. In second round, Non programmable Calculator will be allowed. There will be maximum 1 member in each team.', 3, 2, 500, 'The participant must be enrolled as an undergraduate in any recognized Institute/University. The participant should not be affiliated with organizing or management of this event.', 'Team with the most correct answers will be declared as winner.'),
(7, 'Poster Designing', 'Registration is open for 2018 Conference', 'fa-object-group', 'This competition will Test your skills in Complex Maths, algebric-equation based problems, which will be solved using the complexity of BODMAS Rules. The competition is designed to evaluate conceptual knowledge, basic understanding and logical interpretation ability of students. Our objective is to identify and promote mathematical genius.', 'There will be two rounds in competition. First round Around 50 MCQ’s and the duration time is 25 mints. Then we have 30 mints break. In second round includes 50 MCQ’s plus 10 questions and the duration time will be of 50 mints. There will be no negative marking. After the examination, the candidates would have to return both the Question booklet and the Answer sheet to the invigilator. Message will be sent to winning team’s heads only. The overall time of the Competition is around 2 hours. In second round, Non programmable Calculator will be allowed. There will be maximum 1 member in each team.', 2, 2, 500, 'The participant must be enrolled as an undergraduate in any recognized Institute/University. The participant should not be affiliated with organizing or management of this event.', 'Team with the most correct answers will be declared as winner.'),
(8, 'Fifa', 'Registration is open for 2018 Conference', 'fa-futbol-o', 'This competition will Test your skills in Complex Maths, algebric-equation based problems, which will be solved using the complexity of BODMAS Rules. The competition is designed to evaluate conceptual knowledge, basic understanding and logical interpretation ability of students. Our objective is to identify and promote mathematical genius.', 'There will be two rounds in competition. First round Around 50 MCQ’s and the duration time is 25 mints. Then we have 30 mints break. In second round includes 50 MCQ’s plus 10 questions and the duration time will be of 50 mints. There will be no negative marking. After the examination, the candidates would have to return both the Question booklet and the Answer sheet to the invigilator. Message will be sent to winning team’s heads only. The overall time of the Competition is around 2 hours. In second round, Non programmable Calculator will be allowed. There will be maximum 1 member in each team.', 3, 2, 500, 'The participant must be enrolled as an undergraduate in any recognized Institute/University. The participant should not be affiliated with organizing or management of this event.', 'Team with the most correct answers will be declared as winner.');

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `id` int(11) NOT NULL,
  `event_name` varchar(100) NOT NULL,
  `event_image` varchar(255) NOT NULL,
  `event_des` text NOT NULL,
  `author` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  `date` date NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`id`, `event_name`, `event_image`, `event_des`, `author`, `status`, `date`, `updated`) VALUES
(13, 'AKSC\'17', 'wsi-imageoptim-new2-1024x1024.png', 'Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries', 'shariq', 'Published', '2018-01-11', '2018-02-21 02:26:56'),
(14, 'Inter Computing Competition', 'wsi-imageoptim-11233779_641421589328483_209259474926211083_n-1024x1024.jpg', 'Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries', 'shariq', 'Published', '2018-02-17', '2018-02-21 02:22:51'),
(10, 'Art Behind Speed Programming', 'absp.jpg', 'Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries', 'shariq', 'Published', '2018-02-14', '2018-02-21 02:27:18'),
(11, 'AKSC\'16', 'wsi-imageoptim-new2-1024x1024.png', 'Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries', 'shariq', 'Published', '2018-02-22', '2018-02-21 02:27:47'),
(12, 'Natural Language Processing Workshop', 'wsi-imageoptim-new2-1024x1024.png', 'Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries', 'shariq', 'Published', '2018-02-05', '2018-02-21 02:28:05');

-- --------------------------------------------------------

--
-- Table structure for table `gallery`
--

CREATE TABLE `gallery` (
  `id` int(11) NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `alt_text` varchar(255) DEFAULT NULL,
  `file_type` varchar(255) NOT NULL,
  `file_size` varchar(100) NOT NULL,
  `author` varchar(255) NOT NULL,
  `status` varchar(100) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gallery`
--

INSERT INTO `gallery` (`id`, `file_name`, `alt_text`, `file_type`, `file_size`, `author`, `status`, `date`) VALUES
(167, 'palekar.png', NULL, 'image/png', '44 KB', 'shariq', 'Attached', '2018-02-15 10:08:05'),
(152, 'kidsvideo.MP4', NULL, 'video/mp4', '600 KB', 'shariq', 'Attached', '2018-02-14 05:42:26'),
(159, 'wsi-imageoptim-11233779_641421589328483_209259474926211083_n-1024x1024.jpg', NULL, 'image/jpeg', '87 KB', 'shariq', 'Attached', '2018-02-15 06:34:48'),
(143, 'slide2.jpg', NULL, 'image/jpeg', '283 KB', 'shariq', 'Attached', '2018-02-12 09:03:45'),
(176, 'zainab.jpg', NULL, 'image/jpeg', '13 KB', 'shariq', 'Attached', '2018-02-25 15:02:45'),
(177, 'gearit.jpg', NULL, 'image/jpeg', '6 KB', 'shariq', 'Attached', '2018-03-16 04:53:37'),
(133, 'logo.jpg', NULL, 'image/jpeg', '8 KB', 'shariq', 'Attached', '2018-02-12 08:45:55'),
(157, 'slide6.jpg', NULL, 'image/jpeg', '373 KB', 'shariq', 'Attached', '2018-02-15 06:34:08'),
(156, 'slide5.jpg', NULL, 'image/jpeg', '164 KB', 'shariq', 'Attached', '2018-02-15 06:34:07'),
(128, 'gearit.jpg', NULL, 'image/jpeg', '6 KB', 'shariq', 'Attached', '2018-02-12 04:44:06'),
(155, 'palekar.png', NULL, 'image/png', '44 KB', 'shariq', 'Attached', '2018-02-14 13:14:06'),
(126, 'sheroz.jpg', NULL, 'image/jpeg', '14 KB', 'shariq', 'Attached', '2018-02-12 04:43:02'),
(124, 'rameez.png', NULL, 'image/png', '138 KB', 'shariq', 'Attached', '2018-02-12 04:43:02'),
(123, 'slide5.jpg', NULL, 'image/jpeg', '164 KB', 'shariq', 'Attached', '2018-02-12 04:41:38'),
(122, 'slide4.jpg', NULL, 'image/jpeg', '78 KB', 'shariq', 'Attached', '2018-02-12 04:41:38'),
(120, 'logo.jpg', NULL, 'image/jpeg', '8 KB', 'shariq', 'Attached', '2018-02-12 04:41:38'),
(153, '7Grandee.jpg', NULL, 'image/jpeg', '4 KB', 'shariq', 'Attached', '2018-02-14 13:14:06'),
(117, 'shariq.jpg', NULL, 'image/jpeg', '205 KB', 'shariq', 'Attached', '2018-02-12 04:40:07'),
(119, 'absp.jpg', NULL, 'image/jpeg', '118 KB', 'shariq', 'Attached', '2018-02-12 04:41:38'),
(115, 'rameez.png', NULL, 'image/png', '138 KB', 'shariq', 'Attached', '2018-02-11 17:46:23'),
(114, 'shariq.jpg', NULL, 'image/jpeg', '205 KB', 'shariq', 'Attached', '2018-02-11 17:46:06'),
(168, 'wsi-imageoptim-new2-1024x1024.png', NULL, 'image/png', '195 KB', 'shariq', 'Attached', '2018-02-16 03:04:07'),
(169, 'wsi-imageoptim-natural-1024x1024.jpg', NULL, 'image/jpeg', '116 KB', 'shariq', 'Attached', '2018-02-16 03:11:10'),
(170, 'techno.jpg', NULL, 'image/jpeg', '21 KB', 'shariq', 'Attached', '2018-02-16 03:46:32');

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `id` int(4) UNSIGNED ZEROFILL NOT NULL,
  `uni_name` varchar(255) NOT NULL,
  `team_name` varchar(100) NOT NULL,
  `comp` varchar(100) NOT NULL,
  `team_count` int(11) NOT NULL,
  `m1_name` varchar(100) NOT NULL,
  `m1_contact` varchar(20) NOT NULL,
  `m1_nic` varchar(20) NOT NULL,
  `m1_email` varchar(100) NOT NULL,
  `m2_name` varchar(100) DEFAULT NULL,
  `m2_contact` varchar(20) DEFAULT NULL,
  `m2_nic` varchar(20) DEFAULT NULL,
  `m2_email` varchar(100) DEFAULT NULL,
  `m3_name` varchar(100) DEFAULT NULL,
  `m3_contact` varchar(100) DEFAULT NULL,
  `m3_nic` varchar(20) DEFAULT NULL,
  `m3_email` varchar(100) DEFAULT NULL,
  `m4_name` varchar(100) DEFAULT NULL,
  `m4_contact` varchar(20) DEFAULT NULL,
  `m4_nic` varchar(20) DEFAULT NULL,
  `m4_email` varchar(100) DEFAULT NULL,
  `m5_name` varchar(100) DEFAULT NULL,
  `m5_contact` varchar(20) DEFAULT NULL,
  `m5_nic` varchar(20) DEFAULT NULL,
  `m5_email` varchar(100) DEFAULT NULL,
  `registered_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`id`, `uni_name`, `team_name`, `comp`, `team_count`, `m1_name`, `m1_contact`, `m1_nic`, `m1_email`, `m2_name`, `m2_contact`, `m2_nic`, `m2_email`, `m3_name`, `m3_contact`, `m3_nic`, `m3_email`, `m4_name`, `m4_contact`, `m4_nic`, `m4_email`, `m5_name`, `m5_contact`, `m5_nic`, `m5_email`, `registered_time`) VALUES
(0001, 'Usman Insitute of Technology', 'alph', '', 2, 'shariq', '03152655684', '4240184187091', '', 'alyan', '03112235778', '4240112006313', '', '', '', '', '', NULL, NULL, NULL, '', NULL, NULL, NULL, '', '2018-02-04 12:29:00'),
(0002, 'Usman Insitute of Technology', 'alph', '', 2, 'shariq', '03123046123', '4240184187091', '', 'alyan', '03112655684', '4240184187091', '', '', '', '', '', NULL, NULL, NULL, '', NULL, NULL, NULL, '', '2018-02-04 12:36:55'),
(0003, 'Usma', 'sho', '', 2, 'shariq', '03112655684', '4240184187091', '', 'aklf', '03123046123', '4240184187091', '', '', '', '', '', NULL, NULL, NULL, '', NULL, NULL, NULL, '', '2018-02-04 12:39:51'),
(0004, 'Usman Insitute of Technology', 'aplha', '', 2, 'shariq', '03112655684', '4240184187091', '', 'alyan', '03123046123', '4240184187091', '', '', '', '', '', NULL, NULL, NULL, '', NULL, NULL, NULL, '', '2018-02-04 13:03:23'),
(0005, 'Usman Insitute of Technology', 'aplha', '', 2, 'shariq', '03112655684', '4240184187091', '', 'alyan', '03123046123', '4240184187091', '', '', '', '', '', NULL, NULL, NULL, '', NULL, NULL, NULL, '', '2018-02-04 13:05:16'),
(0006, 'Karachi', 'brackets', '', 2, 'ek admi', '03112655684', '4240184187091', '', 'ek admi', '03152655684', '4240184187091', '', '', '', '', '', NULL, NULL, NULL, '', NULL, NULL, NULL, '', '2018-02-04 14:26:17'),
(0007, 'Karachi', 'brackets', '', 2, 'ek admi', '03112655684', '4240184187091', '', 'ek admi', '03152655684', '4240184187091', '', '', '', '', '', NULL, NULL, NULL, '', NULL, NULL, NULL, '', '2018-02-04 14:26:42'),
(0008, 'Karachi', 'brackets', '', 2, 'ek admi', '03112655684', '4240184187091', '', 'ek admi', '03152655684', '4240184187091', '', '', '', '', '', NULL, NULL, NULL, '', NULL, NULL, NULL, '', '2018-02-04 14:27:00'),
(0009, 'University', 'bravo', '', 2, 'ajkal', '03123046123', '4240184187091', '', 'kdkdi', '03123046123', '4240184187091', '', '', '', '', '', NULL, NULL, NULL, '', NULL, NULL, NULL, '', '2018-02-04 14:31:18'),
(0010, 'University', 'bravo', '', 2, 'ajkal', '03123046123', '4240184187091', '', 'kdkdi', '03123046123', '4240184187091', '', '', '', '', '', NULL, NULL, NULL, '', NULL, NULL, NULL, '', '2018-02-04 14:49:52'),
(0011, 'University', 'bravo', '', 2, 'ajkal', '03123046123', '4240184187091', '', 'kdkdi', '03123046123', '4240184187091', '', '', '', '', '', NULL, NULL, NULL, '', NULL, NULL, NULL, '', '2018-02-04 14:55:00'),
(0012, 'University', 'bravo', '', 2, 'ajkal', '03123046123', '4240184187091', '', 'kdkdi', '03123046123', '4240184187091', '', '', '', '', '', NULL, NULL, NULL, '', NULL, NULL, NULL, '', '2018-02-04 14:56:53'),
(0013, 'University', 'bravo', '', 2, 'ajkal', '03123046123', '4240184187091', '', 'kdkdi', '03123046123', '4240184187091', '', '', '', '', '', NULL, NULL, NULL, '', NULL, NULL, NULL, '', '2018-02-04 14:57:34'),
(0014, 'University', 'bravo', '', 2, 'ajkal', '03123046123', '4240184187091', '', 'kdkdi', '03123046123', '4240184187091', '', '', '', '', '', NULL, NULL, NULL, '', NULL, NULL, NULL, '', '2018-02-04 14:59:51'),
(0015, 'University', 'bravo', '', 2, 'ajkal', '03123046123', '4240184187091', '', 'kdkdi', '03123046123', '4240184187091', '', '', '', '', '', NULL, NULL, NULL, '', NULL, NULL, NULL, '', '2018-02-04 15:00:31'),
(0016, 'University', 'bravo', '', 2, 'ajkal', '03123046123', '4240184187091', '', 'kdkdi', '03123046123', '4240184187091', '', '', '', '', '', NULL, NULL, NULL, '', NULL, NULL, NULL, '', '2018-02-04 15:00:39'),
(0017, 'University', 'bravo', '', 2, 'ajkal', '03123046123', '4240184187091', '', 'kdkdi', '03123046123', '4240184187091', '', '', '', '', '', NULL, NULL, NULL, '', NULL, NULL, NULL, '', '2018-02-04 15:01:34'),
(0018, 'Usman Insitute of Technology', 'shariq', '', 2, 'shariq', '03123046123', '4240184187091', '', 'alyan', '03147895236', '4240184187091', '', NULL, NULL, NULL, '', NULL, NULL, NULL, '', NULL, NULL, NULL, '', '2018-02-04 17:10:17'),
(0019, 'Usman Insitute of Technology', 'shariq', '', 2, 'shariq', '03123046123', '4240184187091', '', 'alyan', '03147895236', '4240184187091', '', NULL, NULL, NULL, '', NULL, NULL, NULL, '', NULL, NULL, NULL, '', '2018-02-04 17:10:46'),
(0020, 'Usman Insitute of Technology', 'shariq', '', 2, 'shariq', '03123046123', '4240184187091', '', 'alyan', '03147895236', '4240184187091', '', NULL, NULL, NULL, '', NULL, NULL, NULL, '', NULL, NULL, NULL, '', '2018-02-04 17:10:50'),
(0021, 'Usman Insitute of Technology', 'shariq', '', 2, 'shariq', '03123046123', '4240184187091', '', 'alyan', '03147895236', '4240184187091', '', NULL, NULL, NULL, '', NULL, NULL, NULL, '', NULL, NULL, NULL, '', '2018-02-04 17:13:11'),
(0022, 'Usman Insitute of Technology', 'shariq', '', 2, 'shariq', '03123046123', '4240184187091', '', 'alyan', '03147895236', '4240184187091', '', NULL, NULL, NULL, '', NULL, NULL, NULL, '', NULL, NULL, NULL, '', '2018-02-04 17:14:43'),
(0023, 'Usman Insitute of Technology', 'shariq', '', 2, 'shariq', '03123046123', '4240184187091', '', 'alyan', '03147895236', '4240184187091', '', NULL, NULL, NULL, '', NULL, NULL, NULL, '', NULL, NULL, NULL, '', '2018-02-04 17:15:13'),
(0024, 'Usman Insitute of Technology', 'shariq', '', 2, 'shariq', '03123046123', '4240184187091', '', 'alyan', '03147895236', '4240184187091', '', NULL, NULL, NULL, '', NULL, NULL, NULL, '', NULL, NULL, NULL, '', '2018-02-04 17:16:11'),
(0025, 'Usman Insitute of Technology', 'shariq', '', 2, 'shariq', '03123046123', '4240184187091', '', 'alyan', '03147895236', '4240184187091', '', NULL, NULL, NULL, '', NULL, NULL, NULL, '', NULL, NULL, NULL, '', '2018-02-04 17:16:27'),
(0039, 'Usman', 'AKSC', 'SP', 1, 'Muhammad', '03123046123', '42401-8418709-1', 'shariq@gmail.com', '', '', '', '', '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2018-08-16 11:35:15'),
(0040, 'Usman Institute Of Technology', 'kdisk', 'SP', 2, 'Muhammad Shariq', '03136523899', '4240184187091', 'shariqx5@gamil.com', 'Muhammad Shariq', '03136523899', '4240184187091', 'shariqx5@gamil.com', '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-02-23 10:13:28'),
(0038, 'Usman Insitute of Technology', 'Apha', 'LB', 1, 'Muhammad Shariq', '03123046123', '4240184187091', 'shariqx5@gmail.com', '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2018-03-08 06:12:42');

-- --------------------------------------------------------

--
-- Table structure for table `team`
--

CREATE TABLE `team` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `image` varchar(100) DEFAULT NULL,
  `description` text NOT NULL,
  `fblink` varchar(255) NOT NULL DEFAULT 'www.facebook.com',
  `glink` varchar(255) NOT NULL DEFAULT 'www.gmail.com',
  `tlink` varchar(255) NOT NULL DEFAULT 'www.twitter.com',
  `designation` varchar(50) NOT NULL,
  `author` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  `updated_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `acm_no` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `team`
--

INSERT INTO `team` (`id`, `name`, `image`, `description`, `fblink`, `glink`, `tlink`, `designation`, `author`, `status`, `updated_on`, `acm_no`) VALUES
(1, 'Prakash Lohana', 'prakash.jpg', 'Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum', 'www.facebook.com', 'www.gmail.com', 'www.twitter.com', 'Facaulty Sponsor', 'shariq', 'Published', '2018-02-17 05:18:08', ''),
(2, 'Sheroz Shamim', 'sheroz.jpg', 'Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum', 'www.facebook.com', 'www.gmail.com', 'www.twitter.com', 'Facaulty Coordinator', 'shariq', 'Published', '2018-02-17 05:18:59', ''),
(3, 'GM Hashmi', 'gm.jpg', 'Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum', 'www.facebook.com', 'www.gmail.com', 'www.twitter.com', 'Chairman', 'shariq', 'Published', '2018-02-17 04:55:19', ''),
(4, 'Taimoor-ul-Hassan', 'taimoor.jpg', 'Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum', 'www.facebook.com', 'www.gmail.com', 'www.twitter.com', 'Vice Chairman', 'shariq', 'Published', '2018-02-17 05:20:10', ''),
(5, 'Syed Abu Hamza', 'hamza.jpg', 'Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum', 'www.facebook.com', 'www.gmail.com', 'www.twitter.com', 'General Secretary', 'shariq', 'Published', '2018-02-17 05:21:31', ''),
(16, 'Ramiz Ansari', 'rameez.png', 'Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum', '', '', '', 'Webmaster', 'shariq', 'Published', '2018-03-08 07:45:52', ''),
(17, 'Syed Sammak', 'sheroz.jpg', 'loreum ipsum ljasf;lasjf;lkasdf;lasdfklj; loreum ipsum ljasf;lasjf;lkasdf;lasdfklj;loreum ipsum ljasf;lasjf;lkasdf;lasdfklj;loreum ipsum ljasf;lasjf;lkasdf;lasdfklj;', '', '', '', 'Web Master', 'shariq', 'Published', '2018-07-23 10:51:25', ''),
(7, 'Zainab Zubair', 'zainab.jpg', 'Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum', 'www.facebook.com', 'www.gmail.com', 'www.twitter.com', 'Membership Chair', 'shariq', 'Published', '2018-02-17 05:23:14', '');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `user_pass` varchar(255) NOT NULL,
  `user_display_name` varchar(255) NOT NULL,
  `user_email` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `user_name`, `user_pass`, `user_display_name`, `user_email`) VALUES
(1, 'shariq', '91648ef3cbb4b8c7a83bfec6605309ed', 'Muhammad Shariq', 'shariqx5@gmail.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `competitions`
--
ALTER TABLE `competitions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gallery`
--
ALTER TABLE `gallery`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `registration`
--
ALTER TABLE `registration`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `team`
--
ALTER TABLE `team`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `competitions`
--
ALTER TABLE `competitions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `gallery`
--
ALTER TABLE `gallery`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=178;
--
-- AUTO_INCREMENT for table `registration`
--
ALTER TABLE `registration`
  MODIFY `id` int(4) UNSIGNED ZEROFILL NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;
--
-- AUTO_INCREMENT for table `team`
--
ALTER TABLE `team`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

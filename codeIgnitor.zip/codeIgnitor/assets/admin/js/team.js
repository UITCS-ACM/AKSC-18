$(document).ready(function(){


    /*FUNCTION FOR SEDING THE ADDED DATA*/
    $(".main-event-area").on('click','.publish-member, .draft-member',function(event){
         event.preventDefault();
         var img=$(".img-div").find("img").attr("class");
         var error=false;
         if(img.indexOf("hide")<=-1){
             var member_name=$("#member-name").val();
             var designation=$("#member-des").val();
             var acm_no=$("#member-acm-no").val();
             var fb_id=$("#member_fbid").val();
             var tw_id=$("#member_twid").val();
             var gmail_id=$("#member_gid").val();
             var des=$("#member-descrip").val();
             var image=$(".img-div").find("img").attr("src");
             var button=$(this).val();
             var id=$("#id").val();
            
            if(member_name==""){
               $("#member-name").siblings(".error").text("Field Must Contain Value");
               error=true;
            }
              
            if(designation==""){
               $("#member-des").siblings(".error").text("Field Must Contain Value");
               error=true;
            }
             
            if(des==""){
               $("#member-descrip").siblings(".error").text("Field Must Contain Value");
               error=true;
            }
            

            
            if(!error){
             $.ajax({
                url:'http://localhost/uitcs_acm/codeignitor/admin/team/add_member',
                type:"POST",
                data:{
                  'id':id,
                  'name':member_name,
                  'designation':designation,
                  'acm_no':acm_no,
                  'fb_id':fb_id,
                  'tw_id':tw_id,
                  'gmail_id':gmail_id,
                  'des':des,
                  'image':image,
                  'button':button
                },
                success:function(){
                   window.location.reload();
                },
                error:function(XMLHttpRequest,textStatus,errorThrown){
                      alert(textStatus+" "+errorThrown);
                }
             });
           }
         }

    });



});

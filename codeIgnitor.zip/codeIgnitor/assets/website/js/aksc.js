$(document).ready(function(){
    
    $(".competition-div").hover(function(){
        $(this).childern().fadeOut(700);
   },function(){
      $(".cd-icon").childern().fadeIn(700);
    });
});